
namespace Abc.EFCore.Data.Entity
{
    public class Student 
    {
        public int StudentId { get; set; }
        public string RegistrationNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address1{get;set;}
    }
}